from tkinter import *
import tkinter as tk

class Pedidos(tk.Frame):

    def __init__(self,padre):
        super().__init__(padre)
        self.widgets()

    def widgets(self):
        pass